package com.example.warehouse.Dto.Response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SalaryReportResponse {
    private Long driverId;
    private String driverName;
    private double baseSalary;
    private double tripSalary;
    private double advancePayment;
    private double totalSalary;
}
