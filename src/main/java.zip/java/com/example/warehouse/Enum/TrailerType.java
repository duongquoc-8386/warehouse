package com.example.warehouse.Enum;

public enum TrailerType {
    CONTAINER,
    FLATBED,
    TANKER,
    OTHER
}
