package com.example.warehouse.Enum;

public enum  TripStatus {
    PENDING, RUNNING, COMPLETED, APPROVED, REJECTED, SUBMITTED
}
