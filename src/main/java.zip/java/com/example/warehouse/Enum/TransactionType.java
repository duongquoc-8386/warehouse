package com.example.warehouse.Enum;

public enum TransactionType {
    IMPORT,     // Nhập kho
    EXPORT,     // Xuất kho
    RETURN,     // Hàng trả lại
    ADJUSTMENT  // Điều chỉnh kiểm kê
}
