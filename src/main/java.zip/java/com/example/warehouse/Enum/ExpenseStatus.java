package com.example.warehouse.Enum;

public enum ExpenseStatus {
    PENDING,    // Đang chờ phê duyệt
    APPROVED,   // Đã duyệt
    REJECTED    // Bị từ chối
}
