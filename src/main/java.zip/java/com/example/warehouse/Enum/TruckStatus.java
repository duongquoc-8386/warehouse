package com.example.warehouse.Enum;

public enum TruckStatus {
    AVAILABLE,
    IN_USE,
    MAINTENANCE
}
