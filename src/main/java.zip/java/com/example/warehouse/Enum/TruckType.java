package com.example.warehouse.Enum;



public enum TruckType {
    HEAD_TRUCK,   // đầu kéo, có thể attach trailer
    CARGO_TRUCK,  // xe tải thường, không kéo mooc
    VAN           // xe van
}
