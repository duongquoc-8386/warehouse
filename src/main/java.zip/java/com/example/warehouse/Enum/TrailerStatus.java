package com.example.warehouse.Enum;

public enum TrailerStatus {
    ACTIVE,
    MAINTENANCE,
    INACTIVE
}
