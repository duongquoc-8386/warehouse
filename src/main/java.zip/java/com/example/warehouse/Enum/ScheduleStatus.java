package com.example.warehouse.Enum;

public enum ScheduleStatus {
    SUBMITTED,    // Đã gửi duyệt
     PENDING,      // Đang chờ duyệt
        APPROVED,     // Đã phê duyệt
        REJECTED,     // Bị từ chối
        COMPLETED     // Đã hoàn thành
}
