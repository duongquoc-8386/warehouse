package com.example.warehouse.Enum;

public enum Role {
    ADMIN,
    NHANVIEN
}
