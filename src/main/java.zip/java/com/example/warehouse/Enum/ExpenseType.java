package com.example.warehouse.Enum;
public enum ExpenseType {
    XangDau,          // xăng dầu
    PhiCauDuong,          // phí cầu đường
    BaoTri,   // bảo trì
    Khac          // khác
}
