package com.example.warehouse.Enum;


public enum ProductCategory {
    DIEN_TU,
    NOI_THAT,

}

