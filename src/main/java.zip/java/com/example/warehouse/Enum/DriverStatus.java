package com.example.warehouse.Enum;

public enum DriverStatus {
    AVAILABLE,   // Sẵn sàng
    ON_DUTY,     // Đang làm việc
    OFF_DUTY,    // Nghỉ
    SUSPENDED    // Tạm dừng
}
